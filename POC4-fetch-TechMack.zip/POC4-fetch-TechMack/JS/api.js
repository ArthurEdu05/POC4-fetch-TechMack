// Quando o botão for clicado, redireciona o usuário para a página 'index.html'
const botao = document.getElementById('voltar');

botao.addEventListener('click', () => {
  window.location.href = 'index.html'; 
});


const pokemonCard = document.querySelector('.pokemonCard'); // Seleciona o contêiner onde as informações dos Pokémons serão exibidas

// Função assíncrona que busca informações sobre Pokémons
const fetchPokemon = async (pokemon) => {
  const response = await fetch(`https://pokeapi.co/api/v2/pokemon?limit=151`); // Faz uma requisição para a API do Pokémon, obtendo os primeiros 151 Pokémons
  const data = await response.json();
  
  // Para cada Pokémon obtido, faz uma nova requisição para obter detalhes deles
  const detalhePokemon = await Promise.all(data.results.map(async(pokemon) => { 
   const response = await fetch(pokemon.url); // Faz a requisição para a URL específica do Pokémon
   return await response.json(); 
  }));
  return detalhePokemon;
}


// Função assíncrona que exibe as informações dos Pokémons na página
const exibirPokemon = async () => {
  const pokemons =  await fetchPokemon(); // Chama a função que busca os Pokémons e aguarda sua conclusão

  // Para cada Pokémon no array retornado, cria elementos HTML e exibe suas informações
  pokemons.forEach(pokemon => { 
    const pokemonDiv = document.createElement('div'); // Cria um novo elemento 'div' para o Pokémon
    pokemonDiv.classList.add('pokemon') // Adiciona a classe 'pokemon' à div

  // Cria um elemento 'h1' para o nome do Pokémon e o insere na div
    const name = document.createElement('h1');
    name.textContent = pokemon.name; 
    pokemonDiv.appendChild(name);
  
  // Cria um elemento 'img' para a imagem do Pokémon e o insere na div
    const image = document.createElement('img');
    image.src = pokemon.sprites.front_default; 
    pokemonDiv.appendChild(image);

  // Cria um parágrafo para o número do Pokémon e o insere na div
    const id = document.createElement('p');
    id.textContent = `Nº: ${pokemon.id}`;
    pokemonDiv.appendChild(id);

  // Cria um parágrafo para a altura do Pokémon e o insere na div
    const height = document.createElement('p');
    height.textContent = `height: ${(pokemon.height / 10).toFixed(2)} m`; // Converte a altura de decímetros para metros
    pokemonDiv.appendChild(height);

  // Cria um parágrafo para o peso do Pokémon e o insere na div
    const weight = document.createElement('p');
    weight.textContent = `weight: ${(pokemon.weight / 10).toFixed(2)} kg`;  // Converte o peso de hectogramas para quilogramas
    pokemonDiv.appendChild(weight);

  // Cria um parágrafo para os tipos do Pokémon e o insere na div
    const types = document.createElement('p');
    types.textContent = `type: ${pokemon.types.map(typeInfo => typeInfo.type.name).join(', ')}`; // Mapeia e exibe os tipos do Pokémon, separando por vírgula
    pokemonDiv.appendChild(types);

  // Insere a div do Pokémon no contêiner principal 'pokemonCard'
    pokemonCard.appendChild(pokemonDiv);
  });
  
}

exibirPokemon(); // Chama a função para exibir os Pokémons