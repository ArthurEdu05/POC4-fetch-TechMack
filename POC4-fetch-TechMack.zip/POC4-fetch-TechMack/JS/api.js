const pokemonName = document.querySelector('.pokemonName')

const fetchPokemon = async (pokemon) => {
  const response = await fetch(`https://pokeapi.co/api/v2/pokemon?limit=151`);
  const data = await response.json();
  return data.results;
  console.log(data);
}
const exibirPokemon = async () => {
  const pokemons =  await fetchPokemon();
  pokemons.forEach(pokemon => {
    const name = document.createElement('div');
    name.textContent = pokemon.name;
    pokemonName.appendChild(name);
  });
  
}

exibirPokemon();