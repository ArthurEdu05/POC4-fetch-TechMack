const botao = document.getElementById('voltar');

botao.addEventListener('click', () => {
  window.location.href = 'index.html'; 
});


const pokemonCard = document.querySelector('.pokemonCard');

const fetchPokemon = async (pokemon) => {
  const response = await fetch(`https://pokeapi.co/api/v2/pokemon?limit=151`);
  const data = await response.json();
  
  const detalhePokemon = await Promise.all(data.results.map(async(pokemon) => {
   const response = await fetch(pokemon.url);
   return await response.json(); 
  }));
  return detalhePokemon;
}



const exibirPokemon = async () => {
  const pokemons =  await fetchPokemon();
  pokemons.forEach(pokemon => {
    const pokemonDiv = document.createElement('div');
    pokemonDiv.classList.add('pokemon')


    const name = document.createElement('h1');
    name.textContent = pokemon.name;
    pokemonDiv.appendChild(name);

    const image = document.createElement('img');
    image.src = pokemon.sprites.front_default; 
    pokemonDiv.appendChild(image);

    const id = document.createElement('p');
    id.textContent = `Nº: ${pokemon.id}`;
    pokemonDiv.appendChild(id);

    const height = document.createElement('p');
    height.textContent = `height: ${(pokemon.height / 10).toFixed(2)} m`;
    pokemonDiv.appendChild(height);

    const weight = document.createElement('p');
    weight.textContent = `weight: ${(pokemon.weight / 10).toFixed(2)} kg`;
    pokemonDiv.appendChild(weight);

    const types = document.createElement('p');
    types.textContent = `type: ${pokemon.types.map(typeInfo => typeInfo.type.name).join(', ')}`;
    pokemonDiv.appendChild(types);

    pokemonCard.appendChild(pokemonDiv);
  });
  
}

exibirPokemon();