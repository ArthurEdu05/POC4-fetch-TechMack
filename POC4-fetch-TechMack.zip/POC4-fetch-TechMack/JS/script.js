/*Desenvolvido por:
-Arthur Eduardo de Almeida Santos - 10437356
-Guilherme Sampaio Silva - 10443768
-Felipe Ferreira Melantonio - 10443843
*/


// Quando o botão for clicado, redireciona o usuário para a página 'api.html'
const botoes = document.querySelectorAll('#acessarAPI');
botoes.forEach(botao=> {
botao.addEventListener('click', ()=> {
    window.location.href= 'api.html';
});
}); 